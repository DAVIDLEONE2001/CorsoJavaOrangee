package CalcolatriceBasic;

public class sottrazione extends Operazione {

	@Override
	public int esegui() {
		
		
		int sottrazione = this.operando1-this.operando2;
		
		
		// TODO Auto-generated method stub
		return sottrazione;
	}

}

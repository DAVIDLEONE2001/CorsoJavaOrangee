package CalcolatriceBasic;

public class divisione extends Operazione{

	@Override
	public int esegui() {
		int divisione = this.operando1/this.operando2;
		// TODO Auto-generated method stub
		return divisione;
	}

}

package CalcolatriceBasic;

public class somma extends Operazione{
	
	

	@Override
	public int esegui() {
		
		int somma = this.operando1+this.operando2;
		
		
		
		return somma;
	}

}

package VerificaCF;

public class Persona {

	private String nome;
	private String cogmome;
	private String cf;
	private String nomecognome;

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCogmome() {
		return cogmome;
	}

	public void setCogmome(String cogmome) {
		this.cogmome = cogmome;
	}

	public String getCf() {
		return cf;
	}

	public void setCf(String cf) {
		this.cf = cf;
	}

	public boolean verificaCf() {

		if (this.cf == null) {
			System.out.println("inserire codice fiscale\n");
			return false;
		}

		if ((this.cf.length() == 16) && (this.cf.substring(0, 5).matches("[a-zA-Z]+"))) {

			System.out.println("il codice fiscale di " + this.nome + " � corretto\n");
			return true;

		} else {
			System.out.println("il codice fiscale di " + this.nome + " non � corretto\n");
			return false;
		}

	}

	public String nomeCognome() {

		this.nomecognome = this.nome + " " + this.cogmome;
		return this.nomecognome;

	}

}
